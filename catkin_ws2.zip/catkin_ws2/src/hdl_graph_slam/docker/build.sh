#!/bin/bash
docker build --tag hdl_graph_slam -f noetic/Dockerfile ..
